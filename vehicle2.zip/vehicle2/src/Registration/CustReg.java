package Registration;



import java.io.IOException;

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.PreparedStatement;



import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;



public class CustReg extends HttpServlet {

 private static final long serialVersionUID = 1L;



  public CustReg() {

    super();

    // TODO Auto-generated constructor stub

  }





 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

 // TODO Auto-generated method stub

 response.getWriter().append("Served at: ").append(request.getContextPath());

 }





 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
 System.out.println("*****");
 String name=request.getParameter("name1");
 String surname=request.getParameter("name2");
 String gender=request.getParameter("gender");
String dob=request.getParameter("dob");
String addr=request.getParameter("addr");
String zip=request.getParameter("zip");
String phone=request.getParameter("phone");
String email=request.getParameter("email");
String vech=request.getParameter("vech");
System.out.println(vech);
 String pwd=request.getParameter("pwd");
 

 try

 {

  Class.forName("com.mysql.jdbc.Driver");

  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle","root","root");

  PreparedStatement stm=con.prepareStatement("insert into user(name,surname,gender,email,dob,address,zip,phone,password,access,vehicle_no) values(?,?,?,?,?,?,?,?,?,?,?)");

	  stm.setString(1,name);
	  stm.setString(2,surname);
	  stm.setString(3,gender);
	  stm.setString(4,email);
	  stm.setString(5,dob);
	  stm.setString(6,addr);
	  stm.setString(7,zip);
	  stm.setString(8,phone);
	  stm.setString(9, pwd);
	  stm.setInt(10, 1);
	  stm.setString(11,vech);
  int i=stm.executeUpdate();
System.out.println(i);
  if(i>0)

  {
	  JOptionPane.showMessageDialog(null, "Registration Successfull");
  response.sendRedirect("home.jsp");

  }


  else
  {
	  JOptionPane.showMessageDialog(null, "Some error Occured");
  response.sendRedirect("index.jsp");

 }
 }

 catch(Exception e)

 {
  System.out.println("vechicle number is already present");
  response.sendRedirect("home.jsp");
  

 }



 }



}


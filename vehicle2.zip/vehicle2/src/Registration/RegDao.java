package Registration;



import java.io.IOException;

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.PreparedStatement;



import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;



public class RegDao extends HttpServlet {

 private static final long serialVersionUID = 1L;



  public RegDao() {

    super();

    // TODO Auto-generated constructor stub

  }





 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

 // TODO Auto-generated method stub

 response.getWriter().append("Served at: ").append(request.getContextPath());

 }





 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

 String uname=request.getParameter("uname");

 String email=request.getParameter("email");

 String pwd=request.getParameter("pwd");

 try

 {

  Class.forName("com.mysql.jdbc.Driver");

  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle","root","root");

  PreparedStatement stm=con.prepareStatement("insert into user(name,email,password) values(?,?,?)");

  stm.setString(1,uname);

  stm.setString(2,email);

  stm.setString(3,pwd);

  int i=stm.executeUpdate();

  if(i>0)

  {

  response.sendRedirect("login.jsp");

  }

  else

  response.sendRedirect("reg.jsp");

 }

 catch(Exception e)

 {

  System.out.println(e);

 }



 }



}


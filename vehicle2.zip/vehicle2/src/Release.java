

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Release
 */
public class Release extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Release() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			int i=0;
		String a=request.getParameter("vname");
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle","root","root");
		PreparedStatement stm=con.prepareStatement("select id from user where vehicle_no=?");
		stm.setString(1,a);
		int id=0;
		int price=0;
		ResultSet rs=stm.executeQuery();
		while(rs.next()){
			id=rs.getInt(1);
			System.out.println("id"+id);
			i=1;
		}
		if(i==1)
		{
			
		PreparedStatement st=con.prepareStatement("select price from parking where uid=?");
	    st.setInt(1,id);
	    ResultSet rr=st.executeQuery();
	    while(rr.next())
	    {
	      price=rr.getInt(1);
	    }
		PreparedStatement s=con.prepareStatement("update parking set status=?,uid=? where uid=?");
		s.setInt(1,0);
		s.setInt(2, 0);
		s.setInt(3,id);
		s.executeUpdate();
		
		Date d=new Date();
		SimpleDateFormat format=new SimpleDateFormat("dd/MM/yyyy HH:mm");
		String time=format.format(d);
		String stime[]=time.split(" ");
		
		PreparedStatement s1=con.prepareStatement("update record set outtime=?,outdate=? where uid=?");
		s1.setString(1,stime[1]);
		s1.setString(2,stime[0]);
		//s1.setString(3,null);
		s1.setInt(3,id);
		s1.executeUpdate();

		// calculating time difference
		int amount=0;
		String intime=null;
		String outtime=null;
		String indate=null;
		String outdate=null;
		PreparedStatement ss=con.prepareStatement("select date,intime,outtime,outdate from record where uid=?");
		ss.setInt(1,id);
		ResultSet z=ss.executeQuery();
		while(z.next())
		{
			indate=z.getString(1);
			intime=z.getString(2);
			outtime=z.getString(3);
			outdate=z.getString(4);
			System.out.println("indate"+indate);
			System.out.println("intime"+intime);
			System.out.println("outtime"+outtime);
			System.out.println("outdate"+outdate);
		}
		String t1=indate+" "+intime;
		String t2=outdate+" "+outtime;
		long diff=(long)((format.parse(t2).getTime())-(format.parse(t1).getTime()));
		diff=diff/(60*1000)%60;
		
		//calculating amount
		
		amount=(int) (price*diff);
		HttpSession session=request.getSession();
		session.setAttribute("amount",amount);
		session.setAttribute("id",id);
		PreparedStatement u=con.prepareStatement("update user set amount=? where id=?");
		u.setInt(1,amount);
		u.setInt(2,id);
		u.executeUpdate();
		response.sendRedirect("release1.jsp");
		
		}
		else
		{
			System.out.println("Invalid number");
		}
	
	}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

}

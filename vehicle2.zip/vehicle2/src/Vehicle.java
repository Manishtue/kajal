
import java.io.IOException;

import java.io.PrintWriter;

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.PreparedStatement;

import java.sql.*;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;



/**

 * Servlet implementation class Vehicle

 */

public class Vehicle extends HttpServlet {

 private static final long serialVersionUID = 1L;



  /**

   * @see HttpServlet#HttpServlet()

   */

  public Vehicle() {

    super();

    // TODO Auto-generated constructor stub

  }



 /**

 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)

 */

 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

 // TODO Auto-generated method stub

 response.getWriter().append("Served at: ").append(request.getContextPath());

 }



 /**

 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)

 */

 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

 PrintWriter out=response.getWriter();

 String firstName=request.getParameter("name1");

 String lastName=request.getParameter("name2");

 String dob=request.getParameter("dob");

 String addr=request.getParameter("addr");

 String ph=request.getParameter("phone");

 int phone=Integer.parseInt(ph);

 String email=request.getParameter("email");

 String zip=request.getParameter("zip");

 int code=Integer.parseInt(zip);

 String vno=request.getParameter("vno");

 int v=Integer.parseInt(vno);

 int i=0;

 try

 {

  Class.forName("com.mysql.jdbc.Driver");

  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle","root","root");

  PreparedStatement stm=con.prepareStatement("insert into vehicle(first_name,surname,dob,addr,phone,zip,vehicle_no) values(?,?,?,?,?,?,?)");

  stm.setString(1,firstName);

  stm.setString(2,lastName);

  stm.setString(3,dob);

  stm.setString(4,addr);

  stm.setInt(5,phone);

  stm.setInt(6,code);

  stm.setInt(7,v);

  i=stm.executeUpdate();

  if(i>0)

  {



  out.println("<script type=\"text/javascript\">");

     out.println("alert('Record Succesfully inserted');");

     out.println("location='AdminHome.jsp';");

     out.println("</script>");

  }

  else

  {

  out.println("<script type=\"text/javascript\">");

     out.println("alert('Something left wrong please register again');");

     out.println("location='Vehicle.jsp';");

     out.println("</script>");

  }

 }

 catch(Exception e)

 {

  System.out.println(e);

 }

 }



}

